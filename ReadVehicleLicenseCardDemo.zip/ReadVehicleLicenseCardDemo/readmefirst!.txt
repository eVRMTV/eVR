Please read this first.

The Dienst Wegverkeer, RDW releases this readVehicleLicenseCardDemo demo tool to read the Vehicle License Information that is stored on a smart card.
The rights to use this tool is explained in the license information that is provided in the license.txt. It is a free use "as is" distribution.
This distribution is tested on Microsoft Windows 7/Vista SP2/Server 2003/2008 R2.
You need a smart card reader that supports the ISO7816 specification to read the cards.
The windows driver pcsc-sharp.dll which is part of this distribution is an external open source library. The license is also included in this package.
It is a free to use driver.


------------------------------------
Prerequisites
------------------------------------
A Microsoft Operation System. (Microsoft Windows 7/Vista SP2/Server 2003/2008 R2.)
.NET 4.0 framework installed.
A smart card reader that supports the ISO7816 specification.
A smart card that contains the license applet.

------------------------------------
Unpack/Install
------------------------------------
Unpack the zip to a directory.
Make sure you have the necessary read/edit rights.
Rename the file eVR.ReadVehicleLicenseCardDemo.RENAME into eVR.ReadVehicleLicenseCardDemo.exe
Reason for this .RENAME extension is that most mail servers do not allow .exe in a mail traffic.

------------------------------------
Configuration/Changes
------------------------------------
The file eVR.ReadVehicleLicenseCardDemo.exe.config can be edited in notepad/text editor.
The settings are set on purpose. Please don't change the settings unless you have to. 
If for example, you have a slow smartcard reader, change the CardAccessDelay to a higher value.

Enjoy this demo tool

Regards,

Dienst Wegverkeer,RDW